
4.3.1 / 2019-01-30
==================

  * MAGE-284 Fix issue with OSC and passing the value of the state/region to Klarna
  * MAGE-317 Update copyright info

4.3.0 / 2018-12-11
==================

  * MAGE-54 Add support for finalize call on native checkout
  * MAGE-74 Fix issue with blank values in DB and multiple rows added

4.2.0 / 2018-10-26
==================

  * PI-480 Add DOB to client update call

4.1.0 / 2018-08-24
==================

  * PI-402 Change conditional to better allow merchants to extend/override code
  * PPI-258 Add link to Merchant Portal
  * PPI-405 Added onboarding link
  * PPI-423 Add display of customer's selected payment method when viewing order

4.1.0 / 2018-08-08
==================

  * PI-402 Change conditional to better allow merchants to extend/override code
  * PPI-258 Add link to Merchant Portal
  * PPI-405 Add onboarding link.
  * PPI-423 Add display of payment method

4.0.0 / 2018-06-29
==================

  * PI-349 Encode json data to handle special char
  * PPI-354 Change to use payments endpoint and dynamic payment methods
  * PPI-370 OSC - iframe container shown without KP iframe loaded

3.0.2 / 2018-05-03
==================

  * Fix issues with OSC support

3.0.1 / 2018-03-15
==================

  * Fix issue with OSC displaying Klarna iframe

3.0.0 / 2018-03-12
==================

  * Add support for OSC
  * Add support for EMD data
  * Do not allow PII data to be shared for non-US countries
  * Add CHANGELOG.md
